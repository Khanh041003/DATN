package com.example.myapplication.activity;

import com.journeyapps.barcodescanner.CaptureActivity;

public class ScanerQrCode extends CaptureActivity {
}
