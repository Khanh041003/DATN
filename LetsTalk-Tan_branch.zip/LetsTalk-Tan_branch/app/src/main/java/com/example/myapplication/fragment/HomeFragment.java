package com.example.myapplication.fragment;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.myapplication.MainActivity;
import com.example.myapplication.R;
import com.example.myapplication.activity.LoginActivity;
import com.example.myapplication.activity.MessageListActivity;
import com.example.myapplication.activity.NotificationActivity;
import com.example.myapplication.activity.SearchActivity;
import com.example.myapplication.activity.ViewMediaActivity;
import com.example.myapplication.activity.ViewProfileActivity;
import com.example.myapplication.adapter.PostAdapter;
import com.example.myapplication.model.ImagePostModel;
import com.example.myapplication.model.PostModel;
import com.example.myapplication.server.Url_Api;
import com.example.myapplication.sharedpreferencesmanager.SharedPreferencesManager;
import com.makeramen.roundedimageview.RoundedImageView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;


public class HomeFragment extends Fragment {

    private int user_id;
    private SharedPreferencesManager sharedPreferencesManager;
    private TextView txtName;
    private RoundedImageView img_avatar;

    private ArrayList<PostModel> postModelArrayList = new ArrayList<>();
    private RecyclerView recyclerView;
    private PostAdapter postAdapter;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_home, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        ImageView linear_message = view.findViewById(R.id.linear_message);
        ImageView btn_notification = view.findViewById(R.id.btn_notification);
        ImageView btn_search = view.findViewById(R.id.btn_search);
        txtName = view.findViewById(R.id.txtName);
        img_avatar = view.findViewById(R.id.img_avatar);
        recyclerView = view.findViewById(R.id.recycler_view);

        sharedPreferencesManager = new SharedPreferencesManager(requireContext());
        user_id = sharedPreferencesManager.getUserId();


        LinearLayoutManager layoutManager = new LinearLayoutManager(requireContext());
        recyclerView.setLayoutManager(layoutManager);

        linear_message.setOnClickListener(view1 -> startActivity(new Intent(requireContext(), MessageListActivity.class)));
        btn_notification.setOnClickListener(view12 -> startActivity(new Intent(requireContext(), NotificationActivity.class)));
        img_avatar.setOnClickListener(view13 -> startActivity(new Intent(requireContext(), ViewProfileActivity.class)));
        btn_search.setOnClickListener(view14 -> startActivity(new Intent(requireContext(), SearchActivity.class)));

        if (user_id != 0) {
            getInfo(user_id);
        }

    }

    private void getPost(int user_id) {
        OkHttpClient client = new OkHttpClient();

        // Tạo request để gửi lời gọi HTTP GET đến URL
        String url = Url_Api.getInstance().getPost(user_id);
        Request request = new Request.Builder()
                .url(url)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                e.printStackTrace();
            }

            @SuppressLint("NotifyDataSetChanged")
            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                if (response.isSuccessful()) {
                    ResponseBody responseBody = response.body();
                    if (responseBody != null) {
                        String jsonString = responseBody.string();
                        try {
                            JSONObject jsonObject = new JSONObject(jsonString);
                            boolean status = jsonObject.getBoolean("status");
                            if (status) {
                                JSONArray dataArray = jsonObject.getJSONArray("data");
                                for (int i = 0; i < dataArray.length(); i++) {
                                    JSONObject messageObject = dataArray.getJSONObject(i);

                                    PostModel postModel = new PostModel();

                                    postModel.setPost_id(messageObject.getInt("post_id"));
                                    postModel.setUser_id(messageObject.getInt("user_id"));
                                    postModel.setContent(messageObject.getString("content"));
                                    postModel.setTime(messageObject.getString("time"));
                                    postModel.setHeart_count(messageObject.getInt("heart_count"));
                                    postModel.setComment_count(messageObject.getInt("comment_count"));

                                    // Thay đổi cách lấy dữ liệu từ JSON cho imagePostModelList
                                    JSONArray imageArray = messageObject.getJSONArray("image");
                                    List<ImagePostModel> imagePostModelList = new ArrayList<>();
                                    for (int j = 0; j < imageArray.length(); j++) {
                                        JSONObject imageObject = imageArray.getJSONObject(j);
                                        ImagePostModel imagePostModel = new ImagePostModel();
                                        imagePostModel.setImage_id(imageObject.getInt("image_id"));
                                        imagePostModel.setPost_id(imageObject.getInt("post_id"));
                                        imagePostModel.setImage(imageObject.getString("image"));
                                        imagePostModelList.add(imagePostModel);
                                    }
                                    postModel.setImagePostModelList(imagePostModelList);

                                    postModel.setFull_name(messageObject.getString("full_name"));
                                    postModel.setProfile_image(messageObject.getString("profile_image"));
                                    Log.d(">>>>>>>>>>>", "onResponse: " + messageObject.getString("content"));
                                    postModelArrayList.add(postModel);
                                }
                                requireActivity().runOnUiThread(() -> {
                                    postAdapter = new PostAdapter(requireContext(), postModelArrayList, user_id, requireActivity());
                                    recyclerView.setAdapter(postAdapter);
                                    postAdapter.notifyDataSetChanged();
                                });

                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        });
    }


    private void getInfo(int user_id) {
        OkHttpClient client = new OkHttpClient();

        String url = Url_Api.getInstance().getInfo(user_id);
        Request request = new Request.Builder()
                .url(url)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                if (!isAdded()) {
                    // Fragment đã bị detach khỏi activity, không thực hiện các hoạt động liên quan đến giao diện người dùng
                    return;
                }

                if (response.isSuccessful()) {
                    ResponseBody responseBody = response.body();
                    if (responseBody != null) {
                        String jsonString = responseBody.string();
                        try {
                            JSONObject jsonObject = new JSONObject(jsonString);
                            boolean status = jsonObject.getBoolean("status");
                            if (status) {
                                JSONObject dataObject = jsonObject.getJSONObject("data");

                                requireActivity().runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        // Thực hiện các hoạt động liên quan đến giao diện người dùng trên luồng chính
                                        if (isAdded()) {
                                            try {
                                                txtName.setText(dataObject.getString("full_name"));
                                            } catch (JSONException e) {
                                                throw new RuntimeException(e);
                                            }
                                            try {
                                                Glide.with(requireContext()).load(dataObject.getString("profile_image")).into(img_avatar);
                                            } catch (JSONException e) {
                                                throw new RuntimeException(e);
                                            }
                                        }
                                    }
                                });
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }


        });
    }

    @Override
    public void onResume() {
        super.onResume();
        postModelArrayList.clear();
        getPost(user_id);
    }
}