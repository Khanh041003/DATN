package com.example.myapplication.activity;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.ClipData;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.myapplication.MainActivity;
import com.example.myapplication.R;
import com.example.myapplication.helper.Helper;
import com.example.myapplication.server.Url_Api;
import com.example.myapplication.sharedpreferencesmanager.SharedPreferencesManager;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.makeramen.roundedimageview.RoundedImageView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;

public class EditMyProfileActivity extends AppCompatActivity {
    private EditText edt_date, edt_description, edt_location, edt_name;
    private String tinh, huyen, xa, emailUser;
    private TextView txt_name;
    private ImageView img_avatar, img_cover, btn_back, img_add_image;
    private LinearLayout btn_save;
    private int user_id;
    private RadioGroup rb_GroupGender;
    private RadioButton rb_Nam, rb_Nu, rb_Khac;
    private int year, month, day, checkBirthday;
    private Calendar calendar;
    private Bitmap bitmapAvatar = null;

    // Khai báo biến để lưu trữ ngày tháng năm được chọn
    int selectedYear, selectedMonth, selectedDay;
    private String urlAvatar;
    private static final int REQUEST_CODE_OPEN_GALLERY = 1;
    private static final int  PICK_IMAGE_MULTIPLE = 2;
    ArrayList<Uri> mArrayUri;
    int position = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_my_profile);

        //ánh xạ
        edt_date = findViewById(R.id.edt_date);
        edt_name = findViewById(R.id.edt_Name);
        btn_back = findViewById(R.id.btn_back);
        edt_description = findViewById(R.id.edt_description);
        edt_location = findViewById(R.id.edt_location);
        img_avatar = findViewById(R.id.img_avatar);
        img_add_image = findViewById(R.id.img_add_image);
        img_cover = findViewById(R.id.img_cover);
        btn_save = findViewById(R.id.btn_save);
        rb_Nam = findViewById(R.id.rb_Nam);
        rb_Nu = findViewById(R.id.rb_Nu);
        rb_Khac = findViewById(R.id.rb_Khac);
        rb_GroupGender = findViewById(R.id.rb_GroupGender);

        mArrayUri = new ArrayList<Uri>();

        calendar = Calendar.getInstance();
        year = calendar.get(Calendar.YEAR);
        month = calendar.get(Calendar.MONTH);
        day = calendar.get(Calendar.DAY_OF_MONTH);
        edt_date.setText(day + "-" + (month + 1) + "-" + year);

        img_add_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDialog();
            }
        });

        edt_date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatePickerDialog datePickerDialog = new DatePickerDialog(EditMyProfileActivity.this, AlertDialog.THEME_HOLO_LIGHT, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int yearSelect, int monthOfYear, int dayOfMonth) {
                        // Lưu trữ ngày tháng năm được chọn
                        selectedYear = yearSelect;
                        selectedMonth = monthOfYear;
                        selectedDay = dayOfMonth;

                        // Kiểm tra tuổi để xác định xem có kích hoạt nút Tiếp tục hay không
                        checkBirthday = (year - selectedYear);
                        // Đặt lại EditText với ngày tháng năm được chọn
                        edt_date.setText(selectedDay + "-" + (selectedMonth + 1) + "-" + selectedYear);
                    }
                }, year, month, day);

                datePickerDialog.getDatePicker().setCalendarViewShown(false);
                datePickerDialog.getDatePicker().setSpinnersShown(true);

                // Đặt lại ngày tháng năm trên DatePickerDialog nếu đã chọn trước đó
                if (selectedYear != 0 && selectedMonth != 0 && selectedDay != 0) {
                    datePickerDialog.getDatePicker().updateDate(selectedYear, selectedMonth, selectedDay);
                }

                datePickerDialog.show();

            }
        });


        Helper.changeStatusBarColor(this, R.color.white);
        Helper.changeNavigationColor(this, R.color.white, true);

        city("https://provinces.open-api.vn/api/");

        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(EditMyProfileActivity.this, MyProfileActivity.class));
            }
        });

        SharedPreferencesManager sharedPreferencesManager = new SharedPreferencesManager(this);
        user_id = sharedPreferencesManager.getUserId();

        getProfileUser(user_id);
        btn_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String full_name = edt_name.getText().toString();
                String dob = edt_date.getText().toString();
                String description = edt_description.getText().toString();
                String location = edt_location.getText().toString();
                int selectedId = rb_GroupGender.getCheckedRadioButtonId();
                int sex = -1;
                if (selectedId == R.id.rb_Nam) {
                    sex = 0;
                } else if (selectedId == R.id.rb_Nu) {
                    sex = 1;
                } else if (selectedId == R.id.rb_Khac) {
                    sex = 2;
                }
                saveProfile(user_id, full_name, dob, description, location, sex);
                upLoadImage(bitmapAvatar);
            }
        });
    }

    private void getProfileUser(int user_id) {

        OkHttpClient client = new OkHttpClient();

        String url = Url_Api.getInstance().getProfile(user_id);
        Request request = new Request.Builder().url(url).build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                if (response.isSuccessful()) {
                    ResponseBody responseBody = response.body();
                    if (responseBody != null) {
                        String jsonString = responseBody.string();
                        try {
                            JSONObject jsonObject = new JSONObject(jsonString);
                            boolean status = jsonObject.getBoolean("status");
                            if (status) {
                                JSONObject dataObject = jsonObject.getJSONObject("data");

                                String full_name = dataObject.getString("full_name");
                                String profile_image = dataObject.getString("profile_image");
                                String cover_avatar = dataObject.getString("cover_avatar");
                                String description = dataObject.getString("description");
                                String dob = dataObject.getString("dob");
                                String location = dataObject.getString("location");
                                int selectedId = rb_GroupGender.getCheckedRadioButtonId();
                                int sex = dataObject.getInt("sex");
                                runOnUiThread(new Runnable() {
                                    @SuppressLint("SetTextI18n")
                                    @Override
                                    public void run() {
                                        edt_name.setText(full_name);
                                        edt_date.setText(dob);
                                        edt_description.setText(description);
                                        edt_location.setText(location);
                                        Glide.with(EditMyProfileActivity.this).load(cover_avatar).into(img_cover);
                                        Glide.with(EditMyProfileActivity.this).load(profile_image).into(img_avatar);
                                        if (sex == 0) {
                                            rb_Nam.setChecked(true);
                                        } else if (sex == 1) {
                                            rb_Nu.setChecked(true);
                                        } else if (sex == 2) {
                                            rb_Khac.setChecked(true);
                                        }
                                    }
                                });
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        });
    }

    private void saveProfile(int user_id, String full_name, String dob, String description, String location, int sex) {

        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder().url(Url_Api.getInstance().editProfile(user_id, full_name, dob, description, location, sex)).build();
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                if (response.isSuccessful()) {
                    ResponseBody responseBody = response.body();
                    if (responseBody != null) {
                        String jsonString = responseBody.string();
                        try {
                            JSONObject jsonObject = new JSONObject(jsonString);
                            boolean status = jsonObject.getBoolean("status");
                            String message = jsonObject.getString("message");
                            if (status) {
                                startActivity(new Intent(EditMyProfileActivity.this, MyProfileActivity.class));
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                } else {
                    Toast.makeText(EditMyProfileActivity.this, "Thất bại", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void city(String api) {
        OkHttpClient client = new OkHttpClient();

        Request request = new Request.Builder().url(api).build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    final String responseData = response.body().string();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            renderDataCity(responseData, "city");
                        }
                    });
                }
            }
        });
    }

    private void renderDataCity(String responseData, String select) {
        ArrayList<EditMyProfileActivity.Province> provinces = new ArrayList<>();
        try {
            JSONArray jsonArray = new JSONArray(responseData);
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                String provinceName = jsonObject.getString("name");
                int provinceId = jsonObject.getInt("code");
                EditMyProfileActivity.Province province = new EditMyProfileActivity.Province(provinceName, provinceId);
                provinces.add(province);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        ArrayAdapter<EditMyProfileActivity.Province> adapter = new ArrayAdapter<EditMyProfileActivity.Province>(EditMyProfileActivity.this, android.R.layout.simple_spinner_item, provinces);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        Spinner spinner = findViewById(R.id.city_spinner);
        spinner.setAdapter(adapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                EditMyProfileActivity.Province selectedProvince = (EditMyProfileActivity.Province) parent.getItemAtPosition(position);
                tinh = selectedProvince.getName();
                district(selectedProvince.getId());
                edt_location.setText(xa + ", " + huyen + ", " + tinh);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // do nothing
            }
        });
    }


    private void district(int provinceId) {
        String url = "https://provinces.open-api.vn/api/p/" + provinceId + "?depth=2";
        OkHttpClient client = new OkHttpClient();

        Request request = new Request.Builder().url(url).build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    final String responseData = response.body().string();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            renderDataDistrict(responseData, "district");
                        }
                    });
                }
            }
        });
    }

    private void renderDataDistrict(String responseData, String select) {
        ArrayList<EditMyProfileActivity.District> districts = new ArrayList<>();
        try {
            JSONObject jsonObject = new JSONObject(responseData);
            JSONArray jsonArray = jsonObject.getJSONArray("districts");
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject districtObject = jsonArray.getJSONObject(i);
                String districtName = districtObject.getString("name");
                int districtId = districtObject.getInt("code");
                EditMyProfileActivity.District district = new EditMyProfileActivity.District(districtName, districtId);
                districts.add(district);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        ArrayAdapter<EditMyProfileActivity.District> adapter = new ArrayAdapter<EditMyProfileActivity.District>(EditMyProfileActivity.this, android.R.layout.simple_spinner_item, districts);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        Spinner spinner = findViewById(R.id.district_spinner);
        spinner.setAdapter(adapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                EditMyProfileActivity.District selectedDistrict = (EditMyProfileActivity.District) parent.getItemAtPosition(position);
                huyen = selectedDistrict.getName();
                ward(selectedDistrict.getId());
                edt_location.setText(xa + ", " + huyen + ", " + tinh);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // do nothing
            }
        });
    }

    private void ward(int provinceId) {
        String url = "https://provinces.open-api.vn/api/d/" + provinceId + "?depth=2";
        OkHttpClient client = new OkHttpClient();

        Request request = new Request.Builder().url(url).build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    final String responseData = response.body().string();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            renderDataWard(responseData, "wards");
                        }
                    });
                }
            }
        });
    }

    private void renderDataWard(String responseData, String select) {
        ArrayList<EditMyProfileActivity.Ward> wards = new ArrayList<>();
        try {
            JSONObject jsonObject = new JSONObject(responseData);
            JSONArray jsonArray = jsonObject.getJSONArray("wards");
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject districtObject = jsonArray.getJSONObject(i);
                String districtName = districtObject.getString("name");
                int districtId = districtObject.getInt("code");
                EditMyProfileActivity.Ward ward = new EditMyProfileActivity.Ward(districtName, districtId);
                wards.add(ward);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        ArrayAdapter<EditMyProfileActivity.Ward> adapter = new ArrayAdapter<EditMyProfileActivity.Ward>(EditMyProfileActivity.this, android.R.layout.simple_spinner_item, wards);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        Spinner spinner = findViewById(R.id.ward_spinner);
        spinner.setAdapter(adapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                EditMyProfileActivity.Ward selectedDistrict = (EditMyProfileActivity.Ward) parent.getItemAtPosition(position);
                xa = selectedDistrict.getName();
                edt_location.setText(xa + ", " + huyen + ", " + tinh);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // do nothing
            }
        });
    }



    public class Province {
        private String name;
        private int id;

        public Province(String name, int id) {
            this.name = name;
            this.id = id;
        }

        @Override
        public String toString() {
            return name;
        }

        public int getId() {
            return id;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }
    }

    public class District {
        private String name;
        private int id;

        public District(String name, int id) {
            this.name = name;
            this.id = id;
        }

        public String getName() {
            return name;
        }

        public int getId() {
            return id;
        }

        @Override
        public String toString() {
            return name;
        }
    }

    public class Ward {
        private String name;
        private int code;

        public Ward(String name, int code) {
            this.name = name;
            this.code = code;
        }

        public String getName() {
            return name;
        }

        public int getCode() {
            return code;
        }

        @Override
        public String toString() {
            return name;
        }
    }

    private void showDialog() {
        final CharSequence[] options = {"Chụp ảnh", "Chọn từ thư viện", "Đóng"};

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Thêm ảnh!");
        builder.setItems(options, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int item) {
                if (options[item].equals("Chụp ảnh")) {
                    Intent takePicture = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    startActivityForResult(takePicture, 0);
                } else if (options[item].equals("Chọn từ thư viện")) {
                    Intent intent = new Intent();

                    // setting type to select to be image
                    intent.setType("image/*");

                    // allowing multiple image to be selected
                    intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                    intent.setAction(Intent.ACTION_GET_CONTENT);
                    startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_MULTIPLE);
                } else if (options[item].equals("Đóng")) {
                    dialog.dismiss();
                }
            }
        });
        builder.show();
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_MULTIPLE && resultCode == RESULT_OK && null != data) {
            // Get the Image from data
            if (data.getClipData() != null) {
                ClipData mClipData = data.getClipData();
                int cout = data.getClipData().getItemCount();
                for (int i = 0; i < cout; i++) {
                    // adding imageuri in array
                    Uri imageurl = data.getClipData().getItemAt(i).getUri();
                    mArrayUri.add(imageurl);
                }
                // setting 1st selected image into image switcher
                img_avatar.setImageURI(mArrayUri.get(0));
                position = 0;
            } else {
                Uri imageurl = data.getData();
                mArrayUri.add(imageurl);
                img_avatar.setImageURI(mArrayUri.get(0));
                position = 0;
            }
        } else {
            // show this if no image is selected
            Toast.makeText(this, "You haven't picked Image", Toast.LENGTH_LONG).show();
        }
    }
    private void upLoadImage(Bitmap bitmap) {
        FirebaseStorage firebaseStorage = FirebaseStorage.getInstance();
        StorageReference storageReference = firebaseStorage.getReference();
        StorageReference imageReference = storageReference
                .child("avatar/" + user_id + ".jpg");
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 50, stream);
        byte[] bytes = stream.toByteArray();
        UploadTask uploadTask = imageReference.putBytes(bytes);
        uploadTask.continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
            @Override
            public Task<Uri> then(@NonNull Task<UploadTask.TaskSnapshot> task) throws Exception {
                if (task.isSuccessful()) return imageReference.getDownloadUrl();
                return null;
            }
        }).addOnCompleteListener(new OnCompleteListener<Uri>() {
            @Override
            public void onComplete(@NonNull Task<Uri> task) {
                if (task.isSuccessful()) {
                    Uri downloadUri = task.getResult();
                    urlAvatar = String.valueOf(downloadUri);
                    setAvatar(user_id, urlAvatar);
                }
            }
        });
    }
    private void setAvatar(int user_id, String uri) {
        String avatar = enCodeQrCode(uri);

        OkHttpClient client = new OkHttpClient();

        String url = Url_Api.getInstance().editImageProfile(user_id, avatar);
        Request request = new Request.Builder()
                .url(url)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                if (response.isSuccessful()) {
                    ResponseBody responseBody = response.body();
                    if (responseBody != null) {
                        String jsonString = responseBody.string();
                        try {
                            JSONObject jsonObject = new JSONObject(jsonString);
                            boolean status = jsonObject.getBoolean("status");
                            if (status) {
                                runOnUiThread(() -> {
                                    startActivity(new Intent(EditMyProfileActivity.this, MyProfileActivity.class));
                                });
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        });

    }
    private String enCodeQrCode(String qr_code) {
        return Base64.encodeToString(qr_code.getBytes(), Base64.DEFAULT);
    }
}