package com.example.myapplication.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.myapplication.MainActivity;
import com.example.myapplication.Models.UserModel;
import com.example.myapplication.R;
import com.example.myapplication.adapter.MessagesAdapter;
import com.example.myapplication.model.MessagesModel;
import com.example.myapplication.server.Api_service;
import com.example.myapplication.server.Url_Api;
import com.example.myapplication.sharedpreferencesmanager.SharedPreferencesManager;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import android.widget.ArrayAdapter;
import android.widget.AdapterView;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;

public class EditProfileActivity extends AppCompatActivity {
    EditText edt_name, edt_date, edt_description, edt_location, edt_sex;
    TextView txt_email;
    private String tinh, huyen, xa, emailUser;
    ImageView img_avatar;
    LinearLayout btn_save;
    private int users_id;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);
        //ánh xạ
        edt_name = findViewById(R.id.edt_name);
        txt_email = findViewById(R.id.txt_email);
        edt_date = findViewById(R.id.edt_date);
        edt_description = findViewById(R.id.edt_description);
        edt_location = findViewById(R.id.edt_location);
        img_avatar = findViewById(R.id.img_avatar);
        edt_sex = findViewById(R.id.edt_sex);
        btn_save = findViewById(R.id.btn_save);

        SharedPreferencesManager sharedPreferencesManager = new SharedPreferencesManager(this);
        users_id = sharedPreferencesManager.getUserId();

        city("https://provinces.open-api.vn/api/");

        getProfile(users_id);
        btn_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String full_name = edt_name.getText().toString();
                String dob = edt_date.getText().toString();
                String description = edt_description.getText().toString();
                String location = edt_location.getText().toString();
                String profile_image = String.valueOf(img_avatar.getTextDirection());
                int sex = Integer.parseInt(edt_sex.getText().toString());
                saveProfile(users_id, full_name, dob, description, location, sex);
            }
        });
    }

    private void getProfile(int user_id) {
        OkHttpClient client = new OkHttpClient();

        String url = Url_Api.getInstance().getProfile(user_id);
        Request request = new Request.Builder()
                .url(url)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                if (response.isSuccessful()) {
                    ResponseBody responseBody = response.body();
                    if (responseBody != null) {
                        String jsonString = responseBody.string();
                        try {
                            JSONObject jsonObject = new JSONObject(jsonString);
                            boolean status = jsonObject.getBoolean("status");
                            if (status) {
                                JSONObject dataObject = jsonObject.getJSONObject("data");

                                String full_name = dataObject.getString("full_name");
                                String profile_image = dataObject.getString("profile_image");
                                String email = dataObject.getString("email");
                                String date = dataObject.getString("dob");
                                String description = dataObject.getString("description");
                                String location = dataObject.getString("address");
                                String sex = dataObject.getString("sex");

                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        txt_email.setText(email);
                                        edt_name.setText(full_name);
                                        edt_date.setText(date);
                                        edt_description.setText(description);
                                        edt_location.setText(location);
                                        edt_sex.setText(sex);
                                        Glide.with(EditProfileActivity.this).load(profile_image).into(img_avatar);
                                    }
                                });
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        });
    }

    private void saveProfile(int user_id, String full_name, String dob, String description, String location, int sex) {

        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder()
                .url(Url_Api.getInstance().editProfile(user_id,full_name,dob,description,location,sex))
                .build();
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                if (response.isSuccessful()){
                    ResponseBody   responseBody = response.body();
                    if (responseBody != null){
                        String jsonString = responseBody.string();
                        try {
                            JSONObject jsonObject = new JSONObject(jsonString);
                            boolean status = jsonObject.getBoolean("status");
                            String message = jsonObject.getString("message");
                            if (status) {

                                  startActivity(new Intent(EditProfileActivity.this, MainActivity.class));
                            }
                        }catch (JSONException e){
                            e.printStackTrace();
                        }
                    }
                }else {
                    Toast.makeText(EditProfileActivity.this, "Thất bại", Toast.LENGTH_SHORT).show();
                }
            }
        });


    }
    private void city(String api) {
        OkHttpClient client = new OkHttpClient();

        Request request = new Request.Builder()
                .url(api)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    final String responseData = response.body().string();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            renderDataCity(responseData, "city");
                        }
                    });
                }
            }
        });
    }

    private void renderDataCity(String responseData, String select) {
        ArrayList<EditProfileActivity.Province> provinces = new ArrayList<>();
        try {
            JSONArray jsonArray = new JSONArray(responseData);
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                String provinceName = jsonObject.getString("name");
                int provinceId = jsonObject.getInt("code");
                EditProfileActivity.Province province = new EditProfileActivity.Province(provinceName, provinceId);
                provinces.add(province);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        ArrayAdapter<EditProfileActivity.Province> adapter = new ArrayAdapter<EditProfileActivity.Province>(EditProfileActivity.this, android.R.layout.simple_spinner_item, provinces);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        Spinner spinner = findViewById(R.id.city_spinner);
        spinner.setAdapter(adapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                EditProfileActivity.Province selectedProvince = (EditProfileActivity.Province) parent.getItemAtPosition(position);
                tinh = selectedProvince.getName();
                district(selectedProvince.getId());
                edt_location.setText(xa + ", " + huyen + ", " + tinh);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // do nothing
            }
        });
    }

    private void district(int provinceId) {
        String url = "https://provinces.open-api.vn/api/p/" + provinceId + "?depth=2";
        OkHttpClient client = new OkHttpClient();

        Request request = new Request.Builder()
                .url(url)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    final String responseData = response.body().string();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            renderDataDistrict(responseData, "district");
                        }
                    });
                }
            }
        });
    }

    private void renderDataDistrict(String responseData, String select) {
        ArrayList<EditProfileActivity.District> districts = new ArrayList<>();
        try {
            JSONObject jsonObject = new JSONObject(responseData);
            JSONArray jsonArray = jsonObject.getJSONArray("districts");
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject districtObject = jsonArray.getJSONObject(i);
                String districtName = districtObject.getString("name");
                int districtId = districtObject.getInt("code");
                EditProfileActivity.District district = new EditProfileActivity.District(districtName, districtId);
                districts.add(district);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        ArrayAdapter<EditProfileActivity.District> adapter = new ArrayAdapter<EditProfileActivity.District>(EditProfileActivity.this, android.R.layout.simple_spinner_item, districts);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        Spinner spinner = findViewById(R.id.district_spinner);
        spinner.setAdapter(adapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                EditProfileActivity.District selectedDistrict = (EditProfileActivity.District) parent.getItemAtPosition(position);
                huyen = selectedDistrict.getName();
                ward(selectedDistrict.getId());
                edt_location.setText(xa + ", " + huyen + ", " + tinh);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // do nothing
            }
        });
    }

    private void ward(int provinceId) {
        String url = "https://provinces.open-api.vn/api/d/" + provinceId + "?depth=2";
        OkHttpClient client = new OkHttpClient();

        Request request = new Request.Builder()
                .url(url)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    final String responseData = response.body().string();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            renderDataWard(responseData, "wards");
                        }
                    });
                }
            }
        });
    }

    private void renderDataWard(String responseData, String select) {
        ArrayList<EditProfileActivity.Ward> wards = new ArrayList<>();
        try {
            JSONObject jsonObject = new JSONObject(responseData);
            JSONArray jsonArray = jsonObject.getJSONArray("wards");
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject districtObject = jsonArray.getJSONObject(i);
                String districtName = districtObject.getString("name");
                int districtId = districtObject.getInt("code");
                EditProfileActivity.Ward ward = new EditProfileActivity.Ward(districtName, districtId);
                wards.add(ward);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        ArrayAdapter<EditProfileActivity.Ward> adapter = new ArrayAdapter<EditProfileActivity.Ward>(EditProfileActivity.this, android.R.layout.simple_spinner_item, wards);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        Spinner spinner = findViewById(R.id.ward_spinner);
        spinner.setAdapter(adapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                EditProfileActivity.Ward selectedDistrict = (EditProfileActivity.Ward) parent.getItemAtPosition(position);
                xa = selectedDistrict.getName();
                edt_location.setText(xa + ", " + huyen + ", " + tinh);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // do nothing
            }
        });
    }

    private void navigateToAddressActivity() {
        Intent intent = new Intent(EditProfileActivity.this, MainActivity.class);
        startActivity(intent);
    }

//    private void setAccount() {
//        SharedPreferences sharedPreferences = getSharedPreferences("myinfo", MODE_PRIVATE);
//        SharedPreferences.Editor editor = sharedPreferences.edit();
//
//        String name = sharedPreferences.getString("name", "");
//        String birthday = sharedPreferences.getString("birthday", "");
//        String gender = sharedPreferences.getString("gender", "");
//
//        Map<String, Object> user = new HashMap<>();
//        user.put("email", emailUser);
//        user.put("name", name);
//        user.put("gender", gender);
//        user.put("birthday", birthday);
//        user.put("address", edtAdress.getText().toString());
//        user.put("activestatus", true);
//
//        db.collection("users")
//                .add(user)
//                .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
//                    @Override
//                    public void onSuccess(DocumentReference documentReference) {
//                        editor.clear();
//                        editor.apply();
//                        navigateToAddressActivity();
//                    }
//                });
//    }


    public class Province {
        private String name;
        private int id;

        public Province(String name, int id) {
            this.name = name;
            this.id = id;
        }

        @Override
        public String toString() {
            return name;
        }

        public int getId() {
            return id;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }
    }

    public class District {
        private String name;
        private int id;

        public District(String name, int id) {
            this.name = name;
            this.id = id;
        }

        public String getName() {
            return name;
        }

        public int getId() {
            return id;
        }

        @Override
        public String toString() {
            return name;
        }
    }

    public class Ward {
        private String name;
        private int code;

        public Ward(String name, int code) {
            this.name = name;
            this.code = code;
        }

        public String getName() {
            return name;
        }

        public int getCode() {
            return code;
        }

        @Override
        public String toString() {
            return name;
        }
    }

}
