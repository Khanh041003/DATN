package com.example.myapplication.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.Toast;

import com.example.myapplication.MainActivity;
import com.example.myapplication.R;
import com.example.myapplication.bottomsheet.BottomSheetFogotPassword;
import com.example.myapplication.bottomsheet.BottomSheetSelectedMessage;
import com.example.myapplication.helper.Helper;
import com.example.myapplication.server.Url_Api;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;

public class SignUpActivity extends AppCompatActivity {
    //sign up activity
    EditText edtEmail, edtPassword, edtConfirmPassword, edtName;
    LinearLayout btnConfirm;
    RadioButton rbAgree;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        edtEmail = findViewById(R.id.edtEmail);
        edtPassword = findViewById(R.id.edtPassword);
        edtName = findViewById(R.id.edtName);
        edtConfirmPassword = findViewById(R.id.edtConfirmPassword);

        btnConfirm = findViewById(R.id.btnConfirm);
        rbAgree = findViewById(R.id.rbAgree);

        Helper.changeStatusBarColor(this, R.color.white);
        Helper.changeNavigationColor(this, R.color.white, true);

        SharedPreferences sharedPreferences = getSharedPreferences("user_register", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.clear();
        editor.apply();

        btnConfirm.setOnClickListener(v -> {
            String email = edtEmail.getText().toString();
            String password = edtPassword.getText().toString();
            String name = edtName.getText().toString();
            String confirmPassword = edtConfirmPassword.getText().toString();
            if (checkForm(email,name, password, confirmPassword)) {
                checkEmail(email,password,name);
            }
        });
    }

    private void checkEmail(String email,String full_name,String password) {
        OkHttpClient client = new OkHttpClient();

        String url = Url_Api.getInstance().check_Email(email);
        Request request = new Request.Builder()
                .url(url)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                if (response.isSuccessful()) {
                    ResponseBody responseBody = response.body();
                    if (responseBody != null) {
                        String jsonString = responseBody.string();
                        try {
                            JSONObject jsonObject = new JSONObject(jsonString);
                            boolean status = jsonObject.getBoolean("status");
                            if (status) {
                                runOnUiThread(() -> {
                                    BottomSheetFogotPassword bottomSheetFogotPassword = new BottomSheetFogotPassword(SignUpActivity.this, SignUpActivity.this);
                                    bottomSheetFogotPassword.show(getSupportFragmentManager(), bottomSheetFogotPassword.getTag());
                                });
                            } else {
                                //gọi hàm tạo mới
                                signUp(email,full_name,password);
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        });
    }

    private boolean checkForm(String email, String name, String password, String confirmPassword) {

        if (email.isEmpty()) {
            Toast.makeText(SignUpActivity.this, "Vui lòng nhập email", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (!isValidEmail(email)) {
            Toast.makeText(SignUpActivity.this, "Email không đúng định dạng", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (name.isEmpty()) {
            Toast.makeText(SignUpActivity.this, "Vui lòng nhập Tên", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (password.isEmpty()) {
            Toast.makeText(SignUpActivity.this, "Vui lòng nhập mật khẩu", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (confirmPassword.isEmpty()) {
            Toast.makeText(SignUpActivity.this, "Vui lòng nhập xác nhận mật khẩu", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (!password.equals(confirmPassword)) {
            Toast.makeText(SignUpActivity.this, "Mật khẩu không giống nhau", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (!rbAgree.isChecked()) {
            Toast.makeText(SignUpActivity.this, "Bạn chưa chấp nhận điều khoản", Toast.LENGTH_SHORT).show();
            return false;
        }

        return true;
    }
    private void signUp(String email,String full_name,String password){
        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder()
                .url(Url_Api.getInstance().signUp(email,password,full_name))
                .build();
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                if (response.isSuccessful()) {
                    ResponseBody responseBody = response.body();
                    if (responseBody != null) {
                        String jsonString = responseBody.string();
                        try {
                            JSONObject jsonObject = new JSONObject(jsonString);
                            boolean status = jsonObject.getBoolean("status");
                            String message = jsonObject.getString("message");
                            if (status) {
                                Toast.makeText(SignUpActivity.this, ""+message, Toast.LENGTH_SHORT).show();
                                startActivity(new Intent(SignUpActivity.this, LoginActivity.class));
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                } else {
                    Toast.makeText(SignUpActivity.this, "Thất bại", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    public boolean isValidEmail(String email) {
        String regex = "^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$";
        return email.matches(regex);
    }

//    private void navigateToBirthdayActivity() {
//        Intent intent = new Intent(SignUpActivity.this, NameActivity.class);
//        startActivity(intent);
//    }
}