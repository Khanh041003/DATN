package com.example.myapplication.adapter;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.camera.core.ViewPort;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.myapplication.R;
import com.example.myapplication.activity.EditPostActivity;
import com.example.myapplication.activity.ViewMediaActivity;
import com.example.myapplication.activity.ViewPostActivity;
import com.example.myapplication.model.ImagePostModel;
import com.example.myapplication.model.MessagesModel;
import com.example.myapplication.model.PostModel;
import com.example.myapplication.server.Url_Api;
import com.example.myapplication.sharedpreferencesmanager.SharedPreferencesManager;
import com.makeramen.roundedimageview.RoundedImageView;

import org.json.JSONObject;

import java.io.IOException;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;

public class PostAdapter extends RecyclerView.Adapter<PostAdapter.ViewHolder> {

    private final Context context;
    private final int user_id;
    private final Activity activity;
    private final ArrayList<PostModel> postModelArrayList;

    public PostAdapter(Context context, ArrayList<PostModel> postModelArrayList, int user_id, Activity activity) {
        this.context = context;
        this.postModelArrayList = postModelArrayList;
        this.user_id = user_id;
        this.activity = activity;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_post, parent, false);
        return new ViewHolder(view); // Chỗ này trả về một đối tượng ViewHolder mới
    }


    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        PostModel postModel = postModelArrayList.get(position);

        Glide.with(context).load(postModel.getProfile_image()).into(holder.imgAvatar);
        holder.txtName.setText(postModel.getFull_name());
        holder.txtTime.setText(calculateTime(postModel.getTime()));
        holder.txt_count_heart.setText(String.valueOf(postModel.getHeart_count()));
        holder.txt_count_cmt.setText(String.valueOf(postModel.getComment_count()));
        holder.txtContent.setText(postModel.getContent());

        List<ImagePostModel> imagePostModels = postModel.getImagePostModelList();

        if (imagePostModels != null && !imagePostModels.isEmpty()) {
            holder.img_post.setVisibility(View.VISIBLE);
            Glide.with(context).load(imagePostModels.get(0).getImage()).into(holder.img_post);
            if (imagePostModels.size() > 1) {
                Glide.with(context).load(imagePostModels.get(1).getImage()).into(holder.img_post2);
                holder.img_post2.setVisibility(View.VISIBLE);
            } else {
                holder.img_post2.setVisibility(View.GONE);
            }
        } else {
            holder.img_post.setVisibility(View.GONE);
            holder.img_post2.setVisibility(View.GONE);
        }

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, ViewPostActivity.class);
                Bundle bundle = new Bundle();
                bundle.putSerializable("postModel", postModel);
                intent.putExtras(bundle);
                context.startActivity(intent);
            }
        });

    }

    @Override
    public int getItemCount() {

        return postModelArrayList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        RoundedImageView imgAvatar;
        ImageView img_post, img_post2, btn_heart, btn_commnet, btn_share;
        TextView txtName, txtTime, txtContent, txt_count_heart, txt_count_cmt;

        public ViewHolder(View view) {
            super(view);
            imgAvatar = view.findViewById(R.id.imgAvatar);
            txtName = view.findViewById(R.id.txtName);
            txtTime = view.findViewById(R.id.txtTime);
            txtContent = view.findViewById(R.id.txtContent);

            img_post = view.findViewById(R.id.img_post);
            img_post2 = view.findViewById(R.id.img_post2);
            txt_count_heart = view.findViewById(R.id.txt_count_heart);
            txt_count_cmt = view.findViewById(R.id.txt_count_cmt);
            btn_heart = view.findViewById(R.id.btn_heart);
            btn_commnet = view.findViewById(R.id.btn_commnet);
            btn_share = view.findViewById(R.id.btn_share);

        }
    }
    private static String calculateTime(String time) {
        // Thời điểm hiện tại
        LocalDateTime now = null;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            now = LocalDateTime.now();
        }

        DateTimeFormatter formatter = null;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        }
        LocalDateTime specifiedTime = null;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            specifiedTime = LocalDateTime.parse(time, formatter);
        }

        Duration duration = null;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            duration = Duration.between(specifiedTime, now);
        }
        long seconds = 0;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            seconds = Math.abs(duration.getSeconds());
        }
        long minutes = seconds / 60;
        long hours = minutes / 60;
        long days = hours / 24;
        // Xây dựng chuỗi kết quả
        StringBuilder result = new StringBuilder();

        if (days > 0) {
            result.append(days).append(" ngày trước");
        } else if (hours > 0) {
            result.append(hours).append(" giờ trước");
        } else if (minutes > 0) {
            result.append(minutes).append(" phút trước");
        } else {
            result.append("0 phút trước");
        }

        return result.toString();
    }
}
