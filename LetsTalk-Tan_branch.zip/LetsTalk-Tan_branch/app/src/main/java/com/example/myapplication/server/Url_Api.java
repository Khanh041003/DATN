package com.example.myapplication.server;

import okhttp3.FormBody;
import okhttp3.Request;
import okhttp3.RequestBody;

public class Url_Api {
    private static Url_Api instance;
    private final String BASE_URL = "http://192.168.1.16/duantotnghiep/src/api/";

    private Url_Api() {
    }

    public static Url_Api getInstance() {
        if (instance == null) {
            instance = new Url_Api();
        }
        return instance;
    }

    public String getMessagesList(int userId) {
        String MESSAGES_LIST = "messages/messages_list.php";
        String PARAM_USER_ID = "user_id";
        return BASE_URL + MESSAGES_LIST + "?" + PARAM_USER_ID + "=" + userId;
    }

    public String getMessagesListID(int messages_list_id, int user_id) {
        String MESSAGES_LIST = "messages/get_messages_list.php";
        String PARAM_USER_ID = "messages_list_id";
        String USER = "user_id";
        return BASE_URL + MESSAGES_LIST + "?" + PARAM_USER_ID + "=" + messages_list_id + "&" + USER + "=" + user_id;
    }


    public String getLogin(String email, String password) {
        String LOGIN = "users/login.php";
        String EMAIL = "email";
        String PASSWORD = "password";
        return BASE_URL + LOGIN + "?" + EMAIL + "=" + email + "&" + PASSWORD + "=" + password;
    }

    public String check_Email(String email) {
        String LOGIN = "users/check_email.php";
        String EMAIL = "email";
        return BASE_URL + LOGIN + "?" + EMAIL + "=" + email;
    }

    public String signUp(String email, String password, String full_name) {
        String LOGIN = "users/signup.php";
        String EMAIL = "email";
        String PASSWORD = "password";
        String FULL_NAME = "full_name";
        return BASE_URL + LOGIN + "?" + EMAIL + "=" + email + "&" + PASSWORD + "=" + password + "&" + FULL_NAME + "=" + full_name;
    }


    public String getInfo(int user_id) {
        String INFO = "users/get_info.php";
        String USER_ID = "user_id";
        return BASE_URL + INFO + "?" + USER_ID + "=" + user_id;
    }

    public String editImageProfile(int user_id, String profile_image) {
        String INFO = "users/edit_profile.php";
        String USER_ID = "user_id";
        String IMAGE = "profile_image";
        return BASE_URL + INFO + "?" + USER_ID + "=" + user_id + "&" + IMAGE + "=" + profile_image;
    }


    public String getMessages(int messages_list_id, int pageIndex) {
        String messages = "messages/messages.php";
        String messagesListId = "messages_list_id";
        String page = "page";
        return BASE_URL + messages + "?" + messagesListId + "=" + messages_list_id + "&" + page + "=" + pageIndex;
    }

    public String addMessagesList(int user_id, int sender_id, int receiver_id) {
        String messages = "messages/add_messages_list.php";
        String USER = "user_id";
        String SENDER = "sender_id";
        String RECEIVER = "receiver_id";
        return BASE_URL + messages + "?" + USER + "=" + user_id + "&" + SENDER + "=" + sender_id + "&" + RECEIVER + "=" + receiver_id;
    }

    public String checkMessagesList(int user_id, int sender_id, int receiver_id) {
        String messages = "messages/check_messages_list.php";
        String USER = "user_id";
        String SENDER = "sender_id";
        String RECEIVER = "receiver_id";
        return BASE_URL + messages + "?" + USER + "=" + user_id + "&" + SENDER + "=" + sender_id + "&" + RECEIVER + "=" + receiver_id;
    }

    public String searchMessages(int messages_list_id, String content) {
        String messages = "messages/search_messages.php";
        String messagesListId = "messages_list_id";
        String CONTENT = "content";
        return BASE_URL + messages + "?" + messagesListId + "=" + messages_list_id + "&" + CONTENT + "=" + content;
    }

    public String getProfile(int user_id) {
        String PROFILE = "users/get_info.php";
        String USER_ID = "user_id";
        return BASE_URL + PROFILE + "?" + USER_ID + "=" + user_id;
    }

    public String getFriend(int user_id, int is_friend) {
        String PROFILE = "friend_ship/get_friend.php";
        String USER_ID = "user_id";
        String IS_FRIEND = "is_friend";
        return BASE_URL + PROFILE + "?" + USER_ID + "=" + user_id + "&" + IS_FRIEND + "=" + is_friend;
    }

    public String addFriendShip(int sender_id, int receiver_id, String time) {
        String PROFILE = "friend_ship/add_friend_request.php";
        String Sender_id = "sender_id";
        String Receiver_id = "receiver_id";
        String Time = "time";
        return BASE_URL + PROFILE + "?" + Sender_id + "=" + sender_id + "&" + Receiver_id + "=" + receiver_id + "&" + Time + "=" + time;
    }


    public String getFriendShip(int user_id, int is_friend) {
        String PROFILE = "friend_ship/friend_ship_request.php";
        String USER_ID = "user_id";
        String IS_FRIEND = "is_friend";
        return BASE_URL + PROFILE + "?" + USER_ID + "=" + user_id + "&" + IS_FRIEND + "=" + is_friend;
    }

    public String acceptFriendShip(int sender_id, int receiver_id, String time) {
        String PROFILE = "friend_ship/accept_friend_request.php";
        String USER_ID = "sender_id";
        String RECEIVER = "receiver_id";
        String TIME = "time";
        return BASE_URL + PROFILE + "?" + USER_ID + "=" + sender_id + "&" + RECEIVER + "=" + receiver_id + "&" + TIME + "=" + time;
    }

    public String removeFriendShip(int sender_id, int receiver_id) {
        String PROFILE = "friend_ship/remove_friend_request.php";
        String USER_ID = "sender_id";
        String RECEIVER = "receiver_id";
        return BASE_URL + PROFILE + "?" + USER_ID + "=" + sender_id + "&" + RECEIVER + "=" + receiver_id;
    }

    public String deleteFriend(int friend_ship_id) {
        String PROFILE = "friend_ship/delete_friend.php";
        String SENDER_ID = "friend_ship_id";
        return BASE_URL + PROFILE + "?" + SENDER_ID + "=" + friend_ship_id;

    }

    public String checkIsFriend(int sender_id, int receiver_id) {
        String PROFILE = "friend_ship/check_is_friend.php";
        String SENDER_ID = "sender_id";
        String RECEIVER_ID = "receiver_id";
        return BASE_URL + PROFILE + "?" + SENDER_ID + "=" + sender_id + "&" + RECEIVER_ID + "=" + receiver_id;

    }

    public String getQrCode(int user_id, String time) {
        String PROFILE = "qr_code/get_qr_code.php";
        String USER_ID = "user_id";
        String TIME = "time";
        return BASE_URL + PROFILE + "?" + USER_ID + "=" + user_id + "&" + TIME + "=" + time;
    }

    public String createQrCode(int user_id, String qr_code, String time) {
        String PROFILE = "qr_code/create_qr_code.php";
        String USER_ID = "user_id";
        String QR_CDOE = "qr_code";
        String TIME = "time";
        return BASE_URL + PROFILE + "?" + USER_ID + "=" + user_id + "&" + QR_CDOE + "=" + qr_code + "&" + TIME + "=" + time;

    }

    public String checkQrCode(int user_id, String time) {
        String PROFILE = "qr_code/check_qr_code.php";
        String USER_ID = "user_id";
        String TIME = "time";
        return BASE_URL + PROFILE + "?" + USER_ID + "=" + user_id + "&" + TIME + "=" + time;

    }


    public String editProfile(int user_id, String full_name, String dob, String description, String location, int sex) {
        String EDIT_PROFILE = "users/edit_profile.php";
        String USER_ID = "user_id";
        String FULL_NAME = "full_name";
        String DOB = "dob";
        String DESCRIPTION = "description";
        String LOCATION = "location";
        String SEX = "sex";


        return BASE_URL + EDIT_PROFILE + "?" + USER_ID + "=" + user_id + "&"
                + FULL_NAME + "=" + full_name + "&"
                + DOB + "=" + dob + "&"
                + DESCRIPTION + "=" + description + "&"
                + LOCATION + "=" + location + "&"
                + SEX + "=" + sex;
    }

    public String getPost(int user_id) {
        String POST = "/post/get_post_newfeed.php";
        String USER_ID = "user_id";
        return BASE_URL + POST + "?" + USER_ID + "=" + user_id;
    }

    public String getMyPost(int user_id) {
        String POST = "/post/get_my_post.php";
        String USER_ID = "user_id";
        return BASE_URL + POST + "?" + USER_ID + "=" + user_id;
    }

    public String getCmt(int post_id) {
        String POST = "/post/get_comment.php";
        String USER_ID = "post_id";
        return BASE_URL + POST + "?" + USER_ID + "=" + post_id;
    }

    public String addPost(int user_id, String content, String time, String image) {
        String POST = "post/add_post.php";
        String USER_ID = "user_id";
        String CONTENT = "content";
        String TIME = "time";
        String IMAGE = "image";
        return BASE_URL + POST + "?" + USER_ID + "=" + user_id + "&" + CONTENT + "=" + content + "&" + TIME + "=" + time + "&" + IMAGE + "=" + image;
    }
}
