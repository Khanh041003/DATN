package com.example.myapplication.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.myapplication.R;
import com.example.myapplication.adapter.CommentAdapter;
import com.example.myapplication.adapter.PostAdapter;
import com.example.myapplication.model.CommentModel;
import com.example.myapplication.model.ImagePostModel;
import com.example.myapplication.model.MessagesListModel;
import com.example.myapplication.model.PostModel;
import com.example.myapplication.server.Url_Api;
import com.makeramen.roundedimageview.RoundedImageView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;

public class ViewPostActivity extends AppCompatActivity {
    private RecyclerView rv_commnent;
    private RoundedImageView imgAvatar;
    private ImageView img_post, img_post2, btn_heart, btn_commnet, btn_share;
    private TextView txtName, txtTime, txtContent, txt_count_heart, txt_count_cmt, txtTitle;
    private PostModel postModel;

    private ArrayList<CommentModel> commentModelArrayList = new ArrayList<>();
    private CommentAdapter commentAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_post);

        imgAvatar = findViewById(R.id.imgAvatar);
        txtName = findViewById(R.id.txtName);
        txtTime = findViewById(R.id.txtTime);
        txtContent = findViewById(R.id.txtContent);
        txtTitle = findViewById(R.id.txtTitle);

        img_post = findViewById(R.id.img_post);
        img_post2 = findViewById(R.id.img_post2);
        txt_count_heart = findViewById(R.id.txt_count_heart);
        txt_count_cmt = findViewById(R.id.txt_count_cmt);
        btn_heart = findViewById(R.id.btn_heart);
        btn_commnet = findViewById(R.id.btn_commnet);
        btn_share = findViewById(R.id.btn_share);
        rv_commnent = findViewById(R.id.rv_commnent);

        Bundle bundle = getIntent().getExtras();
        if (bundle == null) {
            return;
        }
        postModel = (PostModel) bundle.get("postModel");


        Glide.with(this).load(postModel.getProfile_image()).into(imgAvatar);
        txtName.setText(postModel.getFull_name());
        txtTime.setText(calculateTime(postModel.getTime()));
        txt_count_heart.setText(String.valueOf(postModel.getHeart_count()));
        txt_count_cmt.setText(String.valueOf(postModel.getComment_count()));
        txtContent.setText(postModel.getContent());
        txtTitle.setText(postModel.getFull_name());


        List<ImagePostModel> imagePostModels = postModel.getImagePostModelList();

        if (imagePostModels != null && !imagePostModels.isEmpty()) {
            // Nếu có ít nhất một ảnh
            img_post.setVisibility(View.VISIBLE);

            // Hiển thị ảnh đầu tiên
            Glide.with(this).load(imagePostModels.get(0).getImage()).into(img_post);

            // Nếu có ít nhất hai ảnh, hiển thị ảnh thứ hai
            if (imagePostModels.size() > 1) {
                Glide.with(this).load(imagePostModels.get(1).getImage()).into(img_post2);
                img_post2.setVisibility(View.VISIBLE);
            } else {
                img_post2.setVisibility(View.GONE);
            }
        } else {
            // Nếu không có ảnh, ẩn ImageView post_image và post_image2
            img_post.setVisibility(View.GONE);
            img_post2.setVisibility(View.GONE);
        }


        LinearLayoutManager layoutManager = new LinearLayoutManager(ViewPostActivity.this);
        rv_commnent.setLayoutManager(layoutManager);


    }


    private void getPost(int user_id) {
        OkHttpClient client = new OkHttpClient();

        // Tạo request để gửi lời gọi HTTP GET đến URL
        String url = Url_Api.getInstance().getCmt(user_id);
        Request request = new Request.Builder()
                .url(url)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                e.printStackTrace();
            }

            @SuppressLint("NotifyDataSetChanged")
            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                if (response.isSuccessful()) {
                    ResponseBody responseBody = response.body();
                    if (responseBody != null) {
                        String jsonString = responseBody.string();
                        try {
                            JSONObject jsonObject = new JSONObject(jsonString);
                            boolean status = jsonObject.getBoolean("status");
                            if (status) {
                                JSONArray dataArray = jsonObject.getJSONArray("data");
                                for (int i = 0; i < dataArray.length(); i++) {
                                    JSONObject messageObject = dataArray.getJSONObject(i);

                                    CommentModel commentModel = new CommentModel();

                                    commentModel.setComment_id(messageObject.getInt("comment_id"));
                                    commentModel.setUser_id(messageObject.getInt("user_id"));
                                    commentModel.setPost_id(messageObject.getInt("post_id"));
                                    commentModel.setContent(messageObject.getString("content"));
                                    commentModel.setTime(calculateTime(messageObject.getString("time")));
                                    commentModel.setFull_name(messageObject.getString("full_name"));
                                    commentModel.setProfile_image(messageObject.getString("profile_image"));
                                    commentModelArrayList.add(commentModel);
                                }
                                runOnUiThread(() -> {
                                    commentAdapter = new CommentAdapter(ViewPostActivity.this, commentModelArrayList, user_id, ViewPostActivity.this);
                                    rv_commnent.setAdapter(commentAdapter);
                                    commentAdapter.notifyDataSetChanged();
                                });

                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        });
    }

    private static String calculateTime(String time) {
        // Thời điểm hiện tại
        LocalDateTime now = null;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            now = LocalDateTime.now();
        }

        DateTimeFormatter formatter = null;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        }
        LocalDateTime specifiedTime = null;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            specifiedTime = LocalDateTime.parse(time, formatter);
        }

        Duration duration = null;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            duration = Duration.between(specifiedTime, now);
        }
        long seconds = 0;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            seconds = Math.abs(duration.getSeconds());
        }
        long minutes = seconds / 60;
        long hours = minutes / 60;
        long days = hours / 24;
        // Xây dựng chuỗi kết quả
        StringBuilder result = new StringBuilder();

        if (days > 0) {
            result.append(days).append(" ngày trước");
        } else if (hours > 0) {
            result.append(hours).append(" giờ trước");
        } else if (minutes > 0) {
            result.append(minutes).append(" phút trước");
        } else {
            result.append("0 phút trước");
        }

        return result.toString();
    }

    @Override
    protected void onResume() {
        super.onResume();
        getPost(postModel.getPost_id());
    }
}